To invoke these Python scripts from executables, put them in a folder whose path is ‘pyscripts_path’ and set the environment variable __PYSCRIPTS_PATH__ to ‘pyscripts_path’.
Remember to add the path to the executables in the system path so as the python script can find them.
